% test YIN

yin 'clarinet.au'
